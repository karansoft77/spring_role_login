 package com.example.demo.controller;

import java.security.Principal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.model.User;
import com.example.demo.repo.UserRepo;




@Controller
public class MainController {
	@Autowired
	private BCryptPasswordEncoder PasswordEncoder;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	UserRepo userRepo;
	
	
	@GetMapping("/")
	public String home() {
		return "index";
	}

	

	@RequestMapping(value = "/error403")
	public String accessDeniedPage(Model model) {
		return "error403";
	}

	@RequestMapping(value = { "/test" }, method = RequestMethod.GET)
	public ModelAndView homePage(ModelAndView model, Principal principal) {
		String name = principal.getName();
		User userByName = userRepo.getUserByName(name);

		String role1 = userByName.getRole();
		
		if (role1.contains("ROLE_ADMIN")) {
			model.setViewName("redirect:admin/dashboard");
			
		} 
		
		return model;
	}

	@RequestMapping(value = { "/user" }, method = RequestMethod.GET)
	public ModelAndView userPage() {
		ModelAndView model = new ModelAndView();
		model.setViewName("user/index");
		return model;
	}

	@RequestMapping(value = { "/admin" }, method = RequestMethod.GET)
	public ModelAndView adminPage() {
		ModelAndView model = new ModelAndView();
		model.setViewName("redirect:/admin/index/");
		return model;
	}
 
	@GetMapping("/signin")
	public String customLogin(Model model) {
		model.addAttribute("Title", "Login- Vision Zeroo");
		return "index";
	}

	
}
