package com.example.demo.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;




@Controller
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private BCryptPasswordEncoder PasswordEncoder;
	

	
	@RequestMapping({ "/dashboard" })
	@ResponseBody
	public String dashboard(final Principal principal) {
		final String name = principal.getName();
		
		return "Admin Page !!!!";
	}

}
